using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace MouseBousou
{
    public partial class Form1 : Form
    {
        // --- Windows API ---
        [DllImport("user32.dll")]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [DllImport("user32.dll")]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        [DllImport("user32.dll")]
        private static extern void mouse_event(uint dwFlags, int dx, int dy, uint dwData, int dwExtraInfo);

        // キーボード入力用 API (keybd_event)
        [DllImport("user32.dll")]
        private static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);

        private const uint MOUSEEVENTF_MOVE = 0x0001;
        private const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
        private const uint MOUSEEVENTF_LEFTUP = 0x0004;
        private const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;
        private const uint MOUSEEVENTF_RIGHTUP = 0x0010;

        private const uint KEYEVENTF_KEYUP = 0x0002;

        private const int HOTKEY_ID = 9000;
        private const uint VK_F8 = 0x77; // F8キー

        private System.Windows.Forms.Timer timerAction;

        // UIコントロール
        private ComboBox cmbMode;
        private ComboBox cmbTarget;     // 連打対象（全キー対応）
        private TrackBar trackBarParam;
        private Label lblStatus;
        private Label lblParamValue;
        private Label lblTargetTitle;
        private Button btnStart;
        private Button btnStop;

        private Random random = new Random();
        private bool isRunning = false;

        public Form1()
        {
            this.Text = "マウス荒ぶれ & 全キー連打ツール (F8対応)";
            this.Size = new Size(350, 320);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            lblStatus = new Label();
            lblStatus.Text = "停止中 [どこでもF8キーでON/OFF]";
            lblStatus.Font = new Font("Meiryo", 9.5f, FontStyle.Bold);
            lblStatus.ForeColor = Color.Gray;
            lblStatus.TextAlign = ContentAlignment.MiddleCenter;
            lblStatus.Location = new Point(12, 10);
            lblStatus.Size = new Size(310, 30);
            this.Controls.Add(lblStatus);

            // モード選択
            Label lblModeTitle = new Label();
            lblModeTitle.Text = "動作モード:";
            lblModeTitle.Font = new Font("Meiryo", 8.5f);
            lblModeTitle.Location = new Point(20, 50);
            lblModeTitle.Size = new Size(70, 20);
            this.Controls.Add(lblModeTitle);

            cmbMode = new ComboBox();
            cmbMode.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbMode.Items.Add("1. 荒ぶれモード (マウス小刻み揺れ)");
            cmbMode.Items.Add("2. 連打モード (マウス・全キー連打)");
            cmbMode.SelectedIndex = 0;
            cmbMode.Location = new Point(95, 47);
            cmbMode.Size = new Size(220, 25);
            cmbMode.SelectedIndexChanged += CmbMode_SelectedIndexChanged;
            this.Controls.Add(cmbMode);

            // 連打対象選択 (全キー登録)
            lblTargetTitle = new Label();
            lblTargetTitle.Text = "連打対象:";
            lblTargetTitle.Font = new Font("Meiryo", 8.5f);
            lblTargetTitle.Location = new Point(20, 85);
            lblTargetTitle.Size = new Size(70, 20);
            lblTargetTitle.Visible = false;
            this.Controls.Add(lblTargetTitle);

            cmbTarget = new ComboBox();
            cmbTarget.DropDownStyle = ComboBoxStyle.DropDownList;

            // マウス＆全キーの項目を追加
            cmbTarget.Items.Add("左クリック");
            cmbTarget.Items.Add("右クリック");

            // アルファベット A〜Z
            for (char c = 'A'; c <= 'Z'; c++)
            {
                cmbTarget.Items.Add($"{c} キー");
            }

            // 数字 0〜9
            for (int i = 0; i <= 9; i++)
            {
                cmbTarget.Items.Add($"数字 {i} キー");
            }

            // ファンクションキー F1〜F12
            for (int i = 1; i <= 12; i++)
            {
                cmbTarget.Items.Add($"F{i} キー");
            }

            // その他よく使う特殊キー
            cmbTarget.Items.Add("Space キー");
            cmbTarget.Items.Add("Shift キー");
            cmbTarget.Items.Add("Ctrl キー");
            cmbTarget.Items.Add("Alt キー");
            cmbTarget.Items.Add("Tab キー");
            cmbTarget.Items.Add("Esc キー");
            cmbTarget.Items.Add("Enter キー");

            cmbTarget.SelectedIndex = 0;
            cmbTarget.Location = new Point(95, 82);
            cmbTarget.Size = new Size(220, 25);
            cmbTarget.Visible = false;
            this.Controls.Add(cmbTarget);

            // パラメータ調整用ラベル
            lblParamValue = new Label();
            lblParamValue.Text = "揺れの幅: 3 px";
            lblParamValue.Font = new Font("Meiryo", 9f);
            lblParamValue.TextAlign = ContentAlignment.MiddleCenter;
            lblParamValue.Location = new Point(12, 115);
            lblParamValue.Size = new Size(310, 20);
            this.Controls.Add(lblParamValue);

            // スライダー
            trackBarParam = new TrackBar();
            trackBarParam.Minimum = 1;
            trackBarParam.Maximum = 30;
            trackBarParam.Value = 3;
            trackBarParam.Location = new Point(30, 140);
            trackBarParam.Size = new Size(270, 45);
            trackBarParam.Scroll += TrackBarParam_Scroll;
            this.Controls.Add(trackBarParam);

            btnStart = new Button();
            btnStart.Text = "開始 (Start)";
            btnStart.BackColor = Color.FromArgb(212, 237, 218);
            btnStart.Location = new Point(50, 195);
            btnStart.Size = new Size(100, 35);
            btnStart.Click += (s, e) => StartAction();
            this.Controls.Add(btnStart);

            btnStop = new Button();
            btnStop.Text = "停止 (Stop)";
            btnStop.BackColor = Color.FromArgb(248, 215, 218);
            btnStop.Location = new Point(180, 195);
            btnStop.Size = new Size(100, 35);
            btnStop.Enabled = false;
            btnStop.Click += (s, e) => StopAction();
            this.Controls.Add(btnStop);

            Label lblDesc = new Label();
            lblDesc.Text = "※ゲーム中でも F8キー でON/OFF切替可能";
            lblDesc.Font = new Font("Meiryo", 8);
            lblDesc.ForeColor = Color.DimGray;
            lblDesc.TextAlign = ContentAlignment.MiddleCenter;
            lblDesc.Location = new Point(12, 245);
            lblDesc.Size = new Size(310, 20);
            this.Controls.Add(lblDesc);

            timerAction = new System.Windows.Forms.Timer();
            timerAction.Interval = 10;
            timerAction.Tick += TimerAction_Tick;
        }

        private void CmbMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMode.SelectedIndex == 0)
            {
                lblTargetTitle.Visible = false;
                cmbTarget.Visible = false;

                trackBarParam.Minimum = 1;
                trackBarParam.Maximum = 30;
                trackBarParam.Value = 3;
                lblParamValue.Text = "揺れの幅: 3 px";
            }
            else
            {
                lblTargetTitle.Visible = true;
                cmbTarget.Visible = true;

                trackBarParam.Minimum = 1;
                trackBarParam.Maximum = 20;
                trackBarParam.Value = 5;
                int ms = trackBarParam.Value * 50;
                lblParamValue.Text = $"連打間隔: {ms} ms";
            }
        }

        private void TrackBarParam_Scroll(object sender, EventArgs e)
        {
            if (cmbMode.SelectedIndex == 0)
            {
                lblParamValue.Text = $"揺れの幅: {trackBarParam.Value} px";
            }
            else
            {
                int ms = trackBarParam.Value * 50;
                lblParamValue.Text = $"連打間隔: {ms} ms";
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            RegisterHotKey(this.Handle, HOTKEY_ID, 0, VK_F8);
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            UnregisterHotKey(this.Handle, HOTKEY_ID);
            base.OnFormClosed(e);
        }

        protected override void WndProc(ref Message m)
        {
            const int WM_HOTKEY = 0x0312;
            if (m.Msg == WM_HOTKEY && m.WParam.ToInt32() == HOTKEY_ID)
            {
                if (isRunning) StopAction();
                else StartAction();
            }
            base.WndProc(ref m);
        }

        private void StartAction()
        {
            isRunning = true;
            cmbMode.Enabled = false;
            cmbTarget.Enabled = false;

            if (cmbMode.SelectedIndex == 0)
            {
                timerAction.Interval = 10;
                lblStatus.Text = "⚡ 荒ぶり中... [F8で停止]";
            }
            else
            {
                timerAction.Interval = trackBarParam.Value * 50;
                lblStatus.Text = $"🔥 連打中 ({cmbTarget.SelectedItem})... [F8で停止]";
            }

            timerAction.Start();
            btnStart.Enabled = false;
            btnStop.Enabled = true;
        }

        private void StopAction()
        {
            isRunning = false;
            timerAction.Stop();
            cmbMode.Enabled = true;
            cmbTarget.Enabled = true;
            lblStatus.Text = "停止中 [どこでもF8キーでON/OFF]";
            lblStatus.ForeColor = Color.Gray;
            btnStart.Enabled = true;
            btnStop.Enabled = false;
        }

        private void TimerAction_Tick(object sender, EventArgs e)
        {
            if (cmbMode.SelectedIndex == 0)
            {
                // --- 荒ぶれモード ---
                int range = trackBarParam.Value;
                int moveX = random.Next(-range, range + 1);
                int moveY = random.Next(-range, range + 1);
                mouse_event(MOUSEEVENTF_MOVE, moveX, moveY, 0, 0);

                Point currentPos = Cursor.Position;
                if (currentPos.X <= 5 && currentPos.Y <= 5)
                {
                    StopAction();
                    MessageBox.Show("安全装置が作動しました（左上端検知）。停止します。", "緊急停止");
                }
            }
            else
            {
                // --- 連打モード（全キー＆マウス対応） ---
                int index = cmbTarget.SelectedIndex;

                if (index == 0) // 左クリック
                {
                    mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
                    mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
                }
                else if (index == 1) // 右クリック
                {
                    mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0);
                    mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);
                }
                else
                {
                    // キーボード判定
                    byte vkCode = 0;
                    string name = cmbTarget.SelectedItem.ToString();

                    if (name.Contains("キー") && name.Length == 5) // A〜Z (例: "A キー")
                    {
                        vkCode = (byte)name[0]; // 文字のASCIIコードがそのまま仮想キーコード(Vk)になる
                    }
                    else if (name.StartsWith("数字")) // 数字 0〜9
                    {
                        char numChar = name[3]; // "数字 0 キー" の 0
                        vkCode = (byte)numChar;  // 0〜9のASCIIコード
                    }
                    else if (name.StartsWith("F")) // ファンクション F1〜F12
                    {
                        // F1(0x70) 〜 F12(0x7B)
                        int fNum = int.Parse(name.Substring(1, name.IndexOf(" ") - 1));
                        vkCode = (byte)(0x6F + fNum);
                    }
                    else
                    {
                        // その他特殊キー
                        if (name.Contains("Space")) vkCode = 0x20;
                        else if (name.Contains("Shift")) vkCode = 0x10;
                        else if (name.Contains("Ctrl")) vkCode = 0x11;
                        else if (name.Contains("Alt")) vkCode = 0x12;
                        else if (name.Contains("Tab")) vkCode = 0x09;
                        else if (name.Contains("Esc")) vkCode = 0x1B;
                        else if (name.Contains("Enter")) vkCode = 0x0D;
                    }

                    if (vkCode != 0)
                    {
                        keybd_event(vkCode, 0, 0, UIntPtr.Zero);
                        keybd_event(vkCode, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
                    }
                }
            }
        }
    }
}